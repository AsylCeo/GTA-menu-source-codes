﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace Stand_Launchpad
{
  public class Changelog : Form
  {
    private IContainer components;
    private WebBrowser webBrowser1;

    public Changelog() => this.InitializeComponent();

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      this.webBrowser1 = new WebBrowser();
      this.SuspendLayout();
      this.webBrowser1.Dock = DockStyle.Fill;
      this.webBrowser1.Location = new Point(0, 0);
      this.webBrowser1.MinimumSize = new Size(20, 20);
      this.webBrowser1.Name = "webBrowser1";
      this.webBrowser1.Size = new Size(800, 450);
      this.webBrowser1.TabIndex = 0;
      this.webBrowser1.Url = new Uri("https://stand.gg/help/changelog-launchpad", UriKind.Absolute);
      this.AutoScaleDimensions = new SizeF(6f, 13f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.ClientSize = new Size(800, 450);
      this.Controls.Add((Control) this.webBrowser1);
      this.Name = nameof (Changelog);
      this.Text = nameof (Changelog);
      this.Icon = (Icon) new ComponentResourceManager(typeof (Launchpad)).GetObject("$this.Icon");
      this.ResumeLayout(false);
    }
  }
}
