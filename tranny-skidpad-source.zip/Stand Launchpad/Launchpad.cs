﻿using Stand_Launchpad.Properties;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Stand_Launchpad
{
  public class Launchpad : Form
  {
    private static Random random = new Random();
    private const string launchpad_version = "1.7.1";
    private const int width_simple = 248;
    private readonly int width_advanced;
    private string[] versions;
    private string stand_dll;
    private int gta_pid;
    private bool game_was_open;
    private bool can_auto_inject = true;
    private bool can_reinject = true;
    private IContainer components;
    private Button InjectBtn;
    private Label InfoText;
    private CheckBox AutoInjectCheckBox;
    private OpenFileDialog CustomDllDialog;
    private Button AdvancedBtn;
    private System.Windows.Forms.Timer ProcessScanTimer;
    private CheckedListBox DllList;
    private Button AddBtn;
    private Button RemoveBtn;
    private NumericUpDown AutoInjectDelaySeconds;
    private Label AutoInjectDelayLabel;
    private System.Windows.Forms.Timer AutoInjectTimer;
    private System.Windows.Forms.Timer GameClosedTimer;
    private System.Windows.Forms.Timer UpdateTimer;
    private ProgressBar progressBar1;
    private Button ChanglogBtn;
    private System.Windows.Forms.Timer ReInjectTimer;
    private Button StandFolderBtn;

    [DllImport("kernel32.dll", SetLastError = true)]
    private static extern IntPtr OpenProcess(
      uint dwDesiredAccess,
      int bInheritHandle,
      uint dwProcessId);

    [DllImport("kernel32.dll", SetLastError = true)]
    private static extern int CloseHandle(IntPtr hObject);

    [DllImport("kernel32.dll", SetLastError = true)]
    private static extern IntPtr GetProcAddress(IntPtr hModule, string lpProcName);

    [DllImport("kernel32.dll", SetLastError = true)]
    private static extern IntPtr GetModuleHandle(string lpModuleName);

    [DllImport("kernel32.dll", SetLastError = true)]
    private static extern IntPtr VirtualAllocEx(
      IntPtr hProcess,
      IntPtr lpAddress,
      IntPtr dwSize,
      uint flAllocationType,
      uint flProtect);

    [DllImport("kernel32.dll", SetLastError = true)]
    private static extern int WriteProcessMemory(
      IntPtr hProcess,
      IntPtr lpBaseAddress,
      byte[] buffer,
      uint size,
      int lpNumberOfBytesWritten);

    [DllImport("kernel32.dll", SetLastError = true)]
    private static extern IntPtr CreateRemoteThread(
      IntPtr hProcess,
      IntPtr lpThreadAttribute,
      IntPtr dwStackSize,
      IntPtr lpStartAddress,
      IntPtr lpParameter,
      uint dwCreationFlags,
      IntPtr lpThreadId);

    public Launchpad()
    {
      this.InitializeComponent();
      if (Settings.Default.MustUpgrade)
      {
        Settings.Default.Upgrade();
        Settings.Default.MustUpgrade = false;
        Settings.Default.Save();
      }
      this.ensureStandBinDirExists();
      this.Text += " 1.7.1";
      this.width_advanced = this.Width;
      this.AutoInjectCheckBox.Checked = Settings.Default.AutoInject;
      this.AutoInjectDelaySeconds.Value = (Decimal) Settings.Default.AutoInjectDelaySeconds;
      this.UpdateTimer.Start();
    }

    private void UpdateTimer_Tick(object sender, EventArgs e)
    {
      this.UpdateTimer.Stop();
      Task<string> stringAsync = new HttpClient().GetStringAsync("https://stand.gg/versions.txt");
      DirectoryInfo directoryInfo = new DirectoryInfo(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + "\\Stand\\Bin\\");
      string str = "";
      try
      {
        stringAsync.Wait();
        str = stringAsync.Result;
      }
      catch (Exception ex)
      {
        foreach (FileInfo file in directoryInfo.GetFiles())
        {
          if (file.Name.StartsWith("Stand ") && file.Name.EndsWith(".dll"))
            str = "1.7.1:" + file.Name.Substring(6, file.Name.Length - 6 - 4);
        }
      }
      if (str.Length == 0)
      {
        int num = (int) this.ShowMessageBox("Failed to get version information. Ensure you're connected to the internet and have no anti-virus program or filewall interfering.");
        Application.Exit();
      }
      this.versions = str.Split(':');
      if (!Settings.Default.Advanced)
        this.UpdateAdvancedMode();
      this.DllList.Items.Add((object) ("Stand " + this.versions[1]));
      if (Settings.Default.CustomDll != "")
      {
        string customDll = Settings.Default.CustomDll;
        char[] chArray = new char[1]{ '|' };
        foreach (object obj in customDll.Split(chArray))
          this.DllList.Items.Add(obj);
      }
      for (int index = 0; index < Settings.Default.InjectDll.Length; ++index)
      {
        if (Settings.Default.InjectDll.Substring(index, 1) == "1")
          this.DllList.SetItemChecked(index, true);
      }
      this.stand_dll = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + "\\Stand\\Bin\\Stand " + this.versions[1] + ".dll";
      if (!System.IO.File.Exists(this.stand_dll))
      {
        try
        {
          foreach (FileSystemInfo file in directoryInfo.GetFiles())
            file.Delete();
          foreach (DirectoryInfo directory in directoryInfo.GetDirectories())
            directory.Delete(true);
        }
        catch (Exception ex)
        {
        }
        this.downloadStandDll();
      }
      this.ScanProcesses(true);
      this.ProcessScanTimer.Start();
      if (!(this.versions[0] != "1.7.1") || this.ShowMessageBox("Launchpad " + this.versions[0] + " is available. Would you like to download it?", MessageBoxButtons.YesNo) != DialogResult.Yes)
        return;
      Process.Start("https://stand.gg/Stand%20Launchpad.exe?" + this.versions[0]);
    }

    private void onDownloadProgress(object sender, DownloadProgressChangedEventArgs e)
    {
      try
      {
        this.progressBar1.Value = e.ProgressPercentage;
      }
      catch (Exception ex)
      {
      }
    }

    private void onDownloadComplete(object sender, AsyncCompletedEventArgs e)
    {
      lock (e.UserState)
        Monitor.Pulse(e.UserState);
    }

    private void ensureStandBinDirExists()
    {
      if (!Directory.Exists(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + "\\Stand"))
        Directory.CreateDirectory(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + "\\Stand");
      if (Directory.Exists(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + "\\Stand\\Bin"))
        return;
      Directory.CreateDirectory(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + "\\Stand\\Bin");
    }

    private void downloadStandDll()
    {
      this.InfoText.Text = "Downloading Stand " + this.versions[1] + "...";
      this.progressBar1.Show();
      Task.Run((Action) (() =>
      {
        WebClient webClient = new WebClient();
        webClient.DownloadProgressChanged += new DownloadProgressChangedEventHandler(this.onDownloadProgress);
        webClient.DownloadFileCompleted += new AsyncCompletedEventHandler(this.onDownloadComplete);
        object userToken = new object();
        lock (userToken)
        {
          webClient.DownloadFileAsync(new Uri("https://stand.gg/Stand%20" + this.versions[1] + ".dll"), this.stand_dll + ".tmp", userToken);
          Monitor.Wait(userToken);
        }
      })).Wait();
      System.IO.File.Move(this.stand_dll + ".tmp", this.stand_dll);
      if (new FileInfo(this.stand_dll).Length < 1024L)
      {
        int num = (int) this.ShowMessageBox("It looks like the DLL download has failed. Ensure you have no anti-virus program interfering.");
      }
      this.progressBar1.Hide();
    }

    private void ProcessScanTimer_Tick(object sender, EventArgs e) => this.ScanProcesses(false);

    private void ScanProcesses(bool first_scan)
    {
      if (!this.can_reinject)
        return;
      foreach (Process process in Process.GetProcesses())
      {
        if (process.ProcessName == "GTA5")
        {
          this.InjectBtn.Enabled = true;
          if (this.gta_pid == process.Id)
            return;
          this.gta_pid = process.Id;
          if (first_scan)
            this.InjectBtn.Focus();
          this.game_was_open = true;
          if (this.AutoInjectCheckBox.Checked && this.can_auto_inject && !first_scan)
          {
            if (Settings.Default.Advanced && this.AutoInjectDelaySeconds.Value > 0M)
            {
              this.InfoText.Text = "Automatically injecting in a few seconds...";
              this.AutoInjectTimer.Interval = (int) this.AutoInjectDelaySeconds.Value * 1000;
              this.AutoInjectTimer.Start();
              return;
            }
            this.Inject();
            return;
          }
          this.InfoText.Text = "Ready to inject.";
          return;
        }
      }
      this.AutoInjectTimer.Stop();
      this.gta_pid = 0;
      this.InjectBtn.Enabled = false;
      this.InfoText.Text = "Ready to inject; just start the game.";
      if (!this.game_was_open)
        return;
      this.game_was_open = false;
      this.can_auto_inject = false;
      this.GameClosedTimer.Start();
    }

    private void InjectBtn_Click(object sender, EventArgs e) => this.Inject();

    private void AutoInjectTimer_Tick(object sender, EventArgs e) => this.Inject();

    private unsafe void Inject()
    {
      this.AutoInjectTimer.Stop();
      this.InjectBtn.Enabled = false;
      this.can_reinject = false;
      List<string> stringList = new List<string>();
      if (Settings.Default.Advanced)
      {
        for (int index = 0; index < this.DllList.Items.Count; ++index)
        {
          if (this.DllList.GetItemChecked(index))
            stringList.Add(index == 0 ? this.stand_dll : this.DllList.Items[index].ToString());
        }
      }
      else
        stringList.Add(this.stand_dll);
      if (stringList.Contains(this.stand_dll) && !System.IO.File.Exists(this.stand_dll))
      {
        this.ensureStandBinDirExists();
        this.downloadStandDll();
      }
      this.InfoText.Text = "Injecting...";
      int num1 = 0;
      IntPtr num2 = Launchpad.OpenProcess(1082U, 1, (uint) this.gta_pid);
      if (num2 == IntPtr.Zero)
      {
        Console.WriteLine("Failed to get a hold of the game's process.");
      }
      else
      {
        IntPtr procAddress = Launchpad.GetProcAddress(Launchpad.GetModuleHandle("kernel32.dll"), "LoadLibraryA");
        if (procAddress == IntPtr.Zero)
        {
          Console.WriteLine("Failed to find LoadLibraryA.");
        }
        else
        {
          string path = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + "\\Stand\\Bin\\Temp";
          if (!Directory.Exists(path))
            Directory.CreateDirectory(path);
          foreach (string str1 in stringList)
          {
            if (!System.IO.File.Exists(str1))
            {
              Console.WriteLine("Couldn't inject " + str1 + " because the file doesn't exist.");
            }
            else
            {
              string str2 = path + "\\SL_" + Launchpad.RandomString(5) + ".dll";
              System.IO.File.Copy(str1, str2);
              IntPtr num3 = Launchpad.VirtualAllocEx(num2, (IntPtr) (void*) null, (IntPtr) str2.Length, 12288U, 64U);
              if (num3 == IntPtr.Zero)
              {
                Console.WriteLine("Couldn't allocate the bytes to represent " + str1);
              }
              else
              {
                byte[] bytes = Encoding.ASCII.GetBytes(str2);
                if (Launchpad.WriteProcessMemory(num2, num3, bytes, (uint) bytes.Length, 0) == 0)
                  Console.WriteLine("Couldn't write " + str2 + " to allocated memory");
                else if (Launchpad.CreateRemoteThread(num2, (IntPtr) (void*) null, IntPtr.Zero, procAddress, num3, 0U, (IntPtr) (void*) null) == IntPtr.Zero)
                  Console.WriteLine("Failed to create remote thread for " + str1);
                else
                  ++num1;
              }
            }
          }
        }
        Launchpad.CloseHandle(num2);
      }
      this.InfoText.Text = "Injected " + num1.ToString() + "/" + stringList.Count.ToString() + " DLLs.";
      if (num1 == 0 && stringList.Count != 0)
      {
        int num4 = (int) this.ShowMessageBox("No DLL was injected. You may need to start the Launchpad as Administrator.");
      }
      this.ReInjectTimer.Start();
    }

    private static string RandomString(int length) => new string(Enumerable.Repeat<string>("ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789", length).Select<string, char>((Func<string, char>) (s => s[Launchpad.random.Next(s.Length)])).ToArray<char>());

    private DialogResult ShowMessageBox(string message, MessageBoxButtons buttons = MessageBoxButtons.OK) => MessageBox.Show(message, "Stand Launchpad 1.7.1", buttons);

    private void Launchpad_FormClosing(object sender, FormClosingEventArgs e)
    {
      Settings.Default.AutoInject = this.AutoInjectCheckBox.Checked;
      Settings.Default.AutoInjectDelaySeconds = (int) this.AutoInjectDelaySeconds.Value;
      Settings.Default.InjectDll = "";
      Settings.Default.CustomDll = "";
      for (int index = 0; index < this.DllList.Items.Count; ++index)
      {
        Settings.Default.InjectDll += this.DllList.GetItemChecked(index) ? "1" : "0";
        if (index != 0)
        {
          // ISSUE: variable of a compiler-generated type
          Settings settings = Settings.Default;
          settings.CustomDll = settings.CustomDll + this.DllList.Items[index].ToString() + "|";
        }
      }
      if (Settings.Default.CustomDll != "")
        Settings.Default.CustomDll = Settings.Default.CustomDll.Substring(0, Settings.Default.CustomDll.Length - 1);
      Settings.Default.Save();
    }

    private void CustomDllDialog_FileOk(object sender, CancelEventArgs e) => this.DllList.SetItemChecked(this.DllList.Items.Add((object) this.CustomDllDialog.FileName), true);

    private void AdvancedBtn_Click(object sender, EventArgs e)
    {
      Settings.Default.Advanced = !Settings.Default.Advanced;
      this.UpdateAdvancedMode();
    }

    private void UpdateAdvancedMode()
    {
      if (Settings.Default.Advanced)
      {
        this.Width = this.width_advanced;
        this.MinimizeBox = true;
        this.InjectBtn.Text = "Inject";
        this.AutoInjectDelaySeconds.Visible = true;
        this.AddBtn.TabStop = true;
        this.RemoveBtn.TabStop = true;
        this.DllList.Visible = true;
      }
      else
      {
        this.MinimizeBox = false;
        this.Width = 248;
        this.InjectBtn.Text = "Inject Stand " + this.versions[1];
        this.AutoInjectDelaySeconds.Visible = false;
        this.AddBtn.TabStop = false;
        this.RemoveBtn.TabStop = false;
        this.DllList.Visible = false;
      }
    }

    private void AddBtn_Click(object sender, EventArgs e)
    {
      int num = (int) this.CustomDllDialog.ShowDialog();
    }

    private void RemoveBtn_Click(object sender, EventArgs e)
    {
      if (this.DllList.SelectedIndex <= 0)
        return;
      this.DllList.Items.RemoveAt(this.DllList.SelectedIndex);
    }

    private void AutoInjectCheckBox_CheckedChanged(object sender, EventArgs e)
    {
      if (this.AutoInjectCheckBox.Checked || !this.AutoInjectTimer.Enabled)
        return;
      this.AutoInjectTimer.Stop();
      this.InfoText.Text = "You may inject now.";
    }

    private void GameClosedTimer_Tick(object sender, EventArgs e)
    {
      this.GameClosedTimer.Stop();
      this.can_auto_inject = true;
    }

    private void ChangelogBtn_Click(object sender, EventArgs e) => new Changelog().Show();

    private void ReInjectTimer_Tick(object sender, EventArgs e)
    {
      this.ReInjectTimer.Stop();
      this.can_reinject = true;
    }

    private void StandFolderBtn_Click(object sender, EventArgs e) => Process.Start(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + "\\Stand");

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      this.components = (IContainer) new Container();
      ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof (Launchpad));
      this.InjectBtn = new Button();
      this.ProcessScanTimer = new System.Windows.Forms.Timer(this.components);
      this.InfoText = new Label();
      this.AutoInjectCheckBox = new CheckBox();
      this.CustomDllDialog = new OpenFileDialog();
      this.AdvancedBtn = new Button();
      this.DllList = new CheckedListBox();
      this.AddBtn = new Button();
      this.RemoveBtn = new Button();
      this.AutoInjectDelaySeconds = new NumericUpDown();
      this.AutoInjectDelayLabel = new Label();
      this.AutoInjectTimer = new System.Windows.Forms.Timer(this.components);
      this.GameClosedTimer = new System.Windows.Forms.Timer(this.components);
      this.UpdateTimer = new System.Windows.Forms.Timer(this.components);
      this.progressBar1 = new ProgressBar();
      this.ChanglogBtn = new Button();
      this.ReInjectTimer = new System.Windows.Forms.Timer(this.components);
      this.StandFolderBtn = new Button();
      this.AutoInjectDelaySeconds.BeginInit();
      this.SuspendLayout();
      this.InjectBtn.BackColor = Color.FromArgb(37, 40, 43);
      this.InjectBtn.Enabled = false;
      this.InjectBtn.FlatAppearance.BorderColor = Color.FromArgb(22, 25, 29);
      this.InjectBtn.FlatStyle = FlatStyle.Flat;
      this.InjectBtn.Location = new Point(12, 12);
      this.InjectBtn.Name = "InjectBtn";
      this.InjectBtn.Size = new Size(208, 23);
      this.InjectBtn.TabIndex = 0;
      this.InjectBtn.Text = "Inject";
      this.InjectBtn.TextAlign = ContentAlignment.MiddleLeft;
      this.InjectBtn.UseVisualStyleBackColor = false;
      this.InjectBtn.Click += new EventHandler(this.InjectBtn_Click);
      this.ProcessScanTimer.Interval = 1000;
      this.ProcessScanTimer.Tick += new EventHandler(this.ProcessScanTimer_Tick);
      this.InfoText.AutoSize = true;
      this.InfoText.Location = new Point(9, 148);
      this.InfoText.Name = "InfoText";
      this.InfoText.Size = new Size(117, 13);
      this.InfoText.TabIndex = 5;
      this.InfoText.Text = "Checking for updates...";
      this.AutoInjectCheckBox.AutoSize = true;
      this.AutoInjectCheckBox.FlatStyle = FlatStyle.Flat;
      this.AutoInjectCheckBox.ForeColor = Color.White;
      this.AutoInjectCheckBox.Location = new Point(12, 128);
      this.AutoInjectCheckBox.Name = "AutoInjectCheckBox";
      this.AutoInjectCheckBox.Size = new Size(202, 17);
      this.AutoInjectCheckBox.TabIndex = 4;
      this.AutoInjectCheckBox.Text = "Automatically inject when game starts.";
      this.AutoInjectCheckBox.UseVisualStyleBackColor = true;
      this.AutoInjectCheckBox.CheckedChanged += new EventHandler(this.AutoInjectCheckBox_CheckedChanged);
      this.CustomDllDialog.Filter = "DLL files|*.dll|All files|*.*";
      this.CustomDllDialog.FileOk += new CancelEventHandler(this.CustomDllDialog_FileOk);
      this.AdvancedBtn.BackColor = Color.FromArgb(37, 40, 43);
      this.AdvancedBtn.FlatAppearance.BorderColor = Color.FromArgb(22, 25, 29);
      this.AdvancedBtn.FlatStyle = FlatStyle.Flat;
      this.AdvancedBtn.Location = new Point(12, 99);
      this.AdvancedBtn.Name = "AdvancedBtn";
      this.AdvancedBtn.Size = new Size(208, 23);
      this.AdvancedBtn.TabIndex = 3;
      this.AdvancedBtn.Text = "Advanced";
      this.AdvancedBtn.TextAlign = ContentAlignment.MiddleLeft;
      this.AdvancedBtn.UseVisualStyleBackColor = false;
      this.AdvancedBtn.Click += new EventHandler(this.AdvancedBtn_Click);
      this.DllList.BackColor = Color.FromArgb(17, 17, 17);
      this.DllList.ForeColor = Color.White;
      this.DllList.FormattingEnabled = true;
      this.DllList.HorizontalScrollbar = true;
      this.DllList.Location = new Point(235, 41);
      this.DllList.Name = "DllList";
      this.DllList.Size = new Size(450, 124);
      this.DllList.TabIndex = 10;
      this.AddBtn.BackColor = Color.FromArgb(37, 40, 43);
      this.AddBtn.FlatAppearance.BorderColor = Color.FromArgb(22, 25, 29);
      this.AddBtn.FlatStyle = FlatStyle.Flat;
      this.AddBtn.Location = new Point(567, 12);
      this.AddBtn.Name = "AddBtn";
      this.AddBtn.Size = new Size(47, 23);
      this.AddBtn.TabIndex = 8;
      this.AddBtn.Text = "Add";
      this.AddBtn.UseVisualStyleBackColor = false;
      this.AddBtn.Click += new EventHandler(this.AddBtn_Click);
      this.RemoveBtn.BackColor = Color.FromArgb(37, 40, 43);
      this.RemoveBtn.FlatAppearance.BorderColor = Color.FromArgb(22, 25, 29);
      this.RemoveBtn.FlatStyle = FlatStyle.Flat;
      this.RemoveBtn.Location = new Point(620, 12);
      this.RemoveBtn.Name = "RemoveBtn";
      this.RemoveBtn.Size = new Size(65, 23);
      this.RemoveBtn.TabIndex = 9;
      this.RemoveBtn.Text = "Remove";
      this.RemoveBtn.UseVisualStyleBackColor = false;
      this.RemoveBtn.Click += new EventHandler(this.RemoveBtn_Click);
      this.AutoInjectDelaySeconds.BackColor = Color.FromArgb(17, 17, 17);
      this.AutoInjectDelaySeconds.ForeColor = Color.White;
      this.AutoInjectDelaySeconds.Location = new Point(415, 15);
      this.AutoInjectDelaySeconds.Maximum = new Decimal(new int[4]
      {
        60,
        0,
        0,
        0
      });
      this.AutoInjectDelaySeconds.Name = "AutoInjectDelaySeconds";
      this.AutoInjectDelaySeconds.Size = new Size(45, 20);
      this.AutoInjectDelaySeconds.TabIndex = 7;
      this.AutoInjectDelayLabel.AutoSize = true;
      this.AutoInjectDelayLabel.ForeColor = Color.White;
      this.AutoInjectDelayLabel.Location = new Point(232, 17);
      this.AutoInjectDelayLabel.Name = "AutoInjectDelayLabel";
      this.AutoInjectDelayLabel.Size = new Size(181, 13);
      this.AutoInjectDelayLabel.TabIndex = 6;
      this.AutoInjectDelayLabel.Text = "Automatic Injection Delay (Seconds):";
      this.AutoInjectTimer.Interval = 1;
      this.AutoInjectTimer.Tick += new EventHandler(this.AutoInjectTimer_Tick);
      this.GameClosedTimer.Interval = 10000;
      this.GameClosedTimer.Tick += new EventHandler(this.GameClosedTimer_Tick);
      this.UpdateTimer.Interval = 1;
      this.UpdateTimer.Tick += new EventHandler(this.UpdateTimer_Tick);
      this.progressBar1.Location = new Point(12, 12);
      this.progressBar1.Name = "progressBar1";
      this.progressBar1.Size = new Size(208, 23);
      this.progressBar1.TabIndex = 0;
      this.progressBar1.Visible = false;
      this.ChanglogBtn.BackColor = Color.FromArgb(37, 40, 43);
      this.ChanglogBtn.FlatAppearance.BorderColor = Color.FromArgb(22, 25, 29);
      this.ChanglogBtn.FlatStyle = FlatStyle.Flat;
      this.ChanglogBtn.ForeColor = Color.White;
      this.ChanglogBtn.Location = new Point(12, 41);
      this.ChanglogBtn.Name = "ChanglogBtn";
      this.ChanglogBtn.Size = new Size(208, 23);
      this.ChanglogBtn.TabIndex = 1;
      this.ChanglogBtn.Text = "Changelog";
      this.ChanglogBtn.TextAlign = ContentAlignment.MiddleLeft;
      this.ChanglogBtn.UseVisualStyleBackColor = false;
      this.ChanglogBtn.Click += new EventHandler(this.ChangelogBtn_Click);
      this.ReInjectTimer.Interval = 3000;
      this.ReInjectTimer.Tick += new EventHandler(this.ReInjectTimer_Tick);
      this.StandFolderBtn.BackColor = Color.FromArgb(37, 40, 43);
      this.StandFolderBtn.FlatAppearance.BorderColor = Color.FromArgb(22, 25, 29);
      this.StandFolderBtn.FlatStyle = FlatStyle.Flat;
      this.StandFolderBtn.Location = new Point(12, 70);
      this.StandFolderBtn.Name = "StandFolderBtn";
      this.StandFolderBtn.Size = new Size(208, 23);
      this.StandFolderBtn.TabIndex = 2;
      this.StandFolderBtn.Text = "Open Stand Folder";
      this.StandFolderBtn.TextAlign = ContentAlignment.MiddleLeft;
      this.StandFolderBtn.UseVisualStyleBackColor = false;
      this.StandFolderBtn.Click += new EventHandler(this.StandFolderBtn_Click);
      this.AutoScaleDimensions = new SizeF(6f, 13f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.BackColor = Color.FromArgb(17, 17, 17);
      this.ClientSize = new Size(694, 175);
      this.Controls.Add((Control) this.StandFolderBtn);
      this.Controls.Add((Control) this.ChanglogBtn);
      this.Controls.Add((Control) this.progressBar1);
      this.Controls.Add((Control) this.AutoInjectDelayLabel);
      this.Controls.Add((Control) this.AutoInjectDelaySeconds);
      this.Controls.Add((Control) this.RemoveBtn);
      this.Controls.Add((Control) this.AddBtn);
      this.Controls.Add((Control) this.DllList);
      this.Controls.Add((Control) this.AdvancedBtn);
      this.Controls.Add((Control) this.AutoInjectCheckBox);
      this.Controls.Add((Control) this.InfoText);
      this.Controls.Add((Control) this.InjectBtn);
      this.ForeColor = Color.White;
      this.FormBorderStyle = FormBorderStyle.FixedSingle;
      this.Icon = (Icon) componentResourceManager.GetObject("$this.Icon");
      this.MaximizeBox = false;
      this.Name = nameof (Launchpad);
      this.Text = "Stand Launchpad";
      this.FormClosing += new FormClosingEventHandler(this.Launchpad_FormClosing);
      this.AutoInjectDelaySeconds.EndInit();
      this.ResumeLayout(false);
      this.PerformLayout();
    }
  }
}
