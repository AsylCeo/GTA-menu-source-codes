#pragma once
#include "drawing.h"
#include "functions.h"
#include "keyboard.h"
#include "pattern.h"
#include "script.h"
#include <functional>
#include <mutex>
#include <memory>
extern HMODULE our_module;
extern Player selectedPlayer;
char* CharKeyboard();
int NumberKeyboard();
void RequestControlOfId(Entity netid);
void RequestControlOfEnt(Entity entity);
void spawn_vehicle(char* vehicle_, bool maxed = true);
void SetRank(int rpvalue);
float degToRad(float degs);
Hash $(std::string str);
void notifyMap(char * fmt, ...);
void notifyMap(std::string str);
template <typename T> T get_stat(Hash stat);
void tse(Player p, uint64_t eventId, uint64_t* args = { 0 });
void Teleport(Vector3 Coords);
void load_ytd(std::string path, std::string file);
void yield();
void transaction(int amount, bool bank = true, int hash = 0xFFFFFFFFA174F633);
void load_model(Hash model);
template <typename T> T get_tunable(int index);
template <typename T> void set_tunable(int index, T value);
void execute_as_script(UINT32 script, std::function<void()> function);
void start_script(bool additional, void(*function)());
void stop_script(void(*function)());
int get_character();
Vector3 coordsOf(Entity entity);
int rndInt(int start, int end);

struct feature {
	bool & b00l;
	std::function<void()> func;
	feature(bool & b, std::function<void()> f) :
		b00l{ b }, func{ f } {}
};

extern std::mutex s_mutex;
extern std::vector<std::shared_ptr<feature>> features;
void fiber();